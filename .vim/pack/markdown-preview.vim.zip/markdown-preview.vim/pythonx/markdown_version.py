#!/usr/bin/env python
# encoding: utf-8

__PLUGIN_VERSION__ = '1.1.0'
__AUTHOR__         = 'Tang Dongxin'
__MAIL__           = 'mike@mikecoder.cn'
